#include <stdio.h>
#include <stdlib.h>

#define USER_MAX 20
// This system can store up to number of users
#define MAX_BOOK_NAME   50
#define MAX_AUTHOR_NAME 50
#define MAX_STUDENT_NAME 50
#define MAX_STUDENT_ADDRESS 300
#define FILE_HEADER_SIZE  sizeof(sFileHeader)
//for books
#define FILE_NAME  "books.bin"
#define MAX_YR  9999
#define MIN_YR  1900
#define MAX_SIZE_USER_NAME 30
#define MAX_SIZE_PASSWORD  20

//admin login
struct login{
	char username[20];
	char password[20];
};

//register the admin
registe(){
	FILE * log;
	log = fopen("filename.txt","w");
	struct login l;
	printf("ENTER USERNAME:"); scanf("%s", l.username);
	printf("ENTER PASSWORD"); scanf("%s", l.password);
	fwrite(&l, sizeof(l),1,log);
	fclose(log);
	printf("ENTER YOUR CREDENTIALS TO LOGIN");
	printf("PRESS ANY KEY TO CONTINUE...");
	getch();
	system("CLS");
	logi();
}
//login the admin and perform admin duties 
logi(){
	char username[20]; char password[20];
	FILE * log;
	log = fopen("filename.txt","r");
	struct login l;
	printf("USERNAME:"); 
	scanf("%s", &username);
	printf("PASSWORD");
	scanf("%s", &password);
	
	while(fread(&l,sizeof(l),1,log)){
		if(strcmp(username,l.username)==0 && strcmp(password,l.password)==0){
			system("CLS");
			printf("\t\tWELCOME ADMIN\n\n");
			int choice;
     printf("1.ADD USERS\n");
    printf("2.DELETE USERS\n");
    printf("enter your choice:");
    scanf("%d",&choice);
    if (choice == 1){
        system("cls");
        printf("\t\tADD NEW USERS\n\n");
        registerUser();	
	}
		} else{
			printf("wrong credentials");
		}
	}
	fclose(log);
}

typedef struct
{
    char name[10];
    char password[10];
} User;
// definition of the structure of a user storing

User list[USER_MAX];
// define a global array, type User, size is USER_MAX

char* filename = "user.txt";
// user.txt need to create a file in your application directory


// Log function
User login()
{
    char name[10];
    char password[10];
    User lg;
    printf("enter name:");
    scanf("%s",name);
    strcpy(lg.name , name);
    printf("enter password:");
    scanf("%s",password);
    strcpy(lg.password,password);
    return lg;
}

// write txt file, there is a row for each user
void writeToFile(User u)
{
    FILE *fw = fopen(filename,"a+");
    fprintf(fw,u.name);
    fprintf(fw,"\t");
    fprintf(fw,u.password);
    fprintf(fw,"\n");
}

// determine whether the user exists
int exist(User u)
{
    int i;
    for(i=0; i<USER_MAX; i++)
    {
        if(0==strcmp(list[i].name ,u.name) && 0==strcmp(list[i].password ,u.password))
        {
            return 1;
        }
    }
    return -1;
}

//registered user
void registerUser()
{
    char name[10];
    char password[10];
    User user;
    int i;

    printf("enter your name:");
    scanf("%s",name);
    strcpy(user.name , name);

    // determine whether there has been a registered user
    for(i=0; i<USER_MAX; i++)
    {
        if(0==strcmp(list[i].name ,name))
        {
            printf("USER ALREADY EXIST");
            return;
        }
    }

    printf("enter your password:");
    scanf("%s",password);
    strcpy(user.password , password);
    writeToFile(user);
}

int menu()
{
	printf("\t\t\t\tWELCOME TO LIBRARY MANAGEMNET SYSTEM\n\n");
    User test[USER_MAX];
    FILE *fp = fopen(filename,"r");
    int i=0;
    User u;
    if(NULL == fp)
    {
        printf("FILE NOT FOUND");
        return -1;
    }
    for(i=0; i<USER_MAX; i++)
    {
        char uname[10];
        char upassword[10];
        fscanf(fp,"%s%s",uname,upassword);

        strcpy(list[i].name , uname);
        strcpy(list[i].password , upassword);
    }
    int choice;
    printf("\t\t\t\t1.ADMIN SECTION\n");
    printf("\t\t\t\t2.STAFF LOG IN\n");
    printf("\t\t\t\t3.USER LOG IN\n");
    printf("\t\t\t\t4.exit\n");
    printf("\t\t\t\tENTER YOUR CHOICE:");
    scanf("%d",&choice);
    
     if (1 == choice){
    int choice;
    system("CLS");
     printf("1.Setup Admin Account\n");
    printf("2.Login\n");
    printf("3.Main Menu\n");
    printf("enter your choice:");
    scanf("%d",&choice);
    
        if(choice == 1){
        system("CLS");
    	registe();	
		}else if (choice == 2){
		system("CLS");
        logi();
        }else if(choice == 3){
         system("CLS");
         menu();	
		}
       	
	}
    else if(2 == choice)
    {
    	
		system("cls");
		printf("\t\tENTER YOUR STAFF LOGIN CREDENTIALS\n\n");
        u=login();
        if(1 == exist(u))
        {
		    int choice;
		    system("CLS");
		    printf("\t\t\tLIBRARY STAFF DASHBOARD\n\n");
		    printf("1.ADD BOOK\n");
		    printf("2.SEARCH BOOK\n");
		    printf("3.VIEW BOOK\n");
		    printf("4.DELETE BOOK\n");
		    printf("enter your choice:");
		    scanf("%d",&choice);
        	if (choice==1){
        	system("CLS");
        	addBookInDataBase();	
			}else if(choice == 2){
				searchBooks();
			} else if(choice == 3){
				viewBooks();
			}else if(choice==4){
				deleteBooks();
			}
            
        }
        else
        {
            printf("WRONG USER OR PASS");
        }

    }else if(3 == choice){
    	system("cls");
    	printf("\t\tENTER YOUR USER LOGIN CREDENTIALS\n\n");
        u=login();
        if(1 == exist(u))
        {
           
		   int choice;
		    system("CLS");
		    printf("\t\t\tLIBRARY USER SECTION\n\n");
		    printf("1.VIEW BOOK\n");
		    printf("2.SEARCH BOOK\n");
		    printf("3.BORROW BOOK\n");
		    printf("ENTER YOUR CHOICE:");
		    scanf("%d",&choice);
        	if (choice==1){
        	system("CLS");
        	viewBooks();	
			}else if(choice == 2){
				searchBooks();
				
			} else if(choice == 3){
				
			}	
        	
            
        }
        else
        {
            printf("WRONG USER OR PASS");
        }
	}
    
    else if(4== choice){
    	exitProgram();
	} else
    {
        return 0;
    }
    
}

void exitProgram(){
	exit(0);
}

typedef struct
{
    int yyyy;
    int mm;
    int dd;
} Date;
typedef struct
{
    char username[MAX_SIZE_USER_NAME];
    char password[MAX_SIZE_PASSWORD];
} sFileHeader;
typedef struct// book store declaration 
{
    unsigned int books_id; // declare the integer data type
    char bookName[MAX_BOOK_NAME];// declare the character data type
    char authorName[MAX_AUTHOR_NAME];// declare the charecter data type
    char studentName[MAX_STUDENT_NAME];// declare the character data type
    char studentAddr[MAX_STUDENT_ADDRESS];// declare the character data type
    Date bookIssueDate;// declare the integer data type
} s_BooksInfo;
void printMessageCenter(const char* message)
{
    int len =0;
    int pos = 0;
    //calculate how many space need to print
    len = (78 - strlen(message))/2;
    printf("\t\t\t");
    for(pos =0 ; pos < len ; pos++)
    {
        //print space
        printf(" ");
    }
    //print message
    printf("%s",message);
}
void headMessage(const char *message)
{
    system("cls");
    printf("\t\t\t###########################################################################");
    printf("\n\t\t\t############                                                   ############");
    printf("\n\t\t\t############            LIBRARY MANAGEMENT SYSTEM              ############");
    printf("\n\t\t\t############                                                   ############");
    printf("\n\t\t\t###########################################################################");
    printf("\n\t\t\t---------------------------------------------------------------------------\n");
    printMessageCenter(message);
    printf("\n\t\t\t----------------------------------------------------------------------------");
}
int isNameValid(const char *name)
{
    int validName = 1;
    int len = 0;
    int index = 0;
    len = strlen(name);
    for(index =0; index <len ; ++index)
    {
        if(!(isalpha(name[index])) && (name[index] != '\n') && (name[index] != ' '))
        {
            validName = 0;
            break;
        }
    }
    return validName;
}
// Function to check leap year.
//Function returns 1 if leap year
int  IsLeapYear(int year)
{
    return (((year % 4 == 0) &&
             (year % 100 != 0)) ||
            (year % 400 == 0));
}
// returns 1 if given date is valid.
int isValidDate(Date *validDate)
{
    //check range of year,month and day
    if (validDate->yyyy > MAX_YR ||
            validDate->yyyy < MIN_YR)
        return 0;
    if (validDate->mm < 1 || validDate->mm > 12)
        return 0;
    if (validDate->dd < 1 || validDate->dd > 31)
        return 0;
    //Handle feb days in leap year
    if (validDate->mm == 2)
    {
        if (IsLeapYear(validDate->yyyy))
            return (validDate->dd <= 29);
        else
            return (validDate->dd <= 28);
    }
    //handle months which has only 30 days
    if (validDate->mm == 4 || validDate->mm == 6 ||
            validDate->mm == 9 || validDate->mm == 11)
        return (validDate->dd <= 30);
    return 1;
}

// Add books in list
void addBookInDataBase()
{
    int days;
    s_BooksInfo addBookInfoInDataBase = {0};
    FILE *fp = NULL;
    int status = 0;
    fp = fopen(FILE_NAME,"ab+");
    if(fp == NULL)
    {
        printf("File is not opened\n");
        exit(1);
    }
    headMessage("ADD NEW BOOKS");
    printf("\n\n\t\t\tENTER YOUR DETAILS BELOW:");
    printf("\n\t\t\t---------------------------------------------------------------------------\n");
    printf("\n\t\t\tBook ID NO  = ");
    fflush(stdin);
    scanf("%u",&addBookInfoInDataBase.books_id);
    do
    {
        printf("\n\t\t\tBook Name  = ");
        fflush(stdin);
        fgets(addBookInfoInDataBase.bookName,MAX_BOOK_NAME,stdin);
        status = isNameValid(addBookInfoInDataBase.bookName);
        if (!status)
        {
            printf("\n\t\t\tName contain invalid character. Please enter again.");
        }
    }
    while(!status);
    do
    {
        printf("\n\t\t\tAuthor Name  = ");
        fflush(stdin);
        fgets(addBookInfoInDataBase.authorName,MAX_AUTHOR_NAME,stdin);
        status = isNameValid(addBookInfoInDataBase.authorName);
        if (!status)
        {
            printf("\n\t\t\tName contain invalid character. Please enter again.");
        }
    }
    while(!status);
    do
    {
        printf("\n\t\t\tStudent Name  = ");
        fflush(stdin);
        fgets(addBookInfoInDataBase.studentName,MAX_STUDENT_NAME,stdin);
        status = isNameValid(addBookInfoInDataBase.studentName);
        if (!status)
        {
            printf("\n\t\t\tName contain invalid character. Please enter again.");
        }
    }
    while(!status);
    do
    {
        //get date year,month and day from user
        printf("\n\t\t\tEnter date in format (day/month/year): ");
        scanf("%d/%d/%d",&addBookInfoInDataBase.bookIssueDate.dd,&addBookInfoInDataBase.bookIssueDate.mm,&addBookInfoInDataBase.bookIssueDate.yyyy);
        //check date validity
        status = isValidDate(&addBookInfoInDataBase.bookIssueDate);
        if (!status)
        {
            printf("\n\t\t\tPlease enter a valid date.\n");
        }
    }
    while(!status);
    fwrite(&addBookInfoInDataBase,sizeof(addBookInfoInDataBase), 1, fp);
    fclose(fp);
    int choice;
		    printf("1.LOG OUT\n");
		    printf("enter your choice:");
		    scanf("%d",&choice);
        	if (choice==1){
        	system("CLS");
        	logout();	
			}
    
}
// search books
void searchBooks()
{
    int found = 0;
    char bookName[MAX_BOOK_NAME] = {0};
    s_BooksInfo addBookInfoInDataBase = {0};
    FILE *fp = NULL;
    int status = 0;
    fp = fopen(FILE_NAME,"rb");
    if(fp == NULL)
    {
        printf("\n\t\t\tFile is not opened\n");
        exit(1);
    }
    headMessage("SEARCH BOOKS");
    //put the control on books detail
    if (fseek(fp,FILE_HEADER_SIZE,SEEK_SET) != 0)
    {
        fclose(fp);
        printf("\n\t\t\tFacing issue while reading file\n");
        exit(1);
    }
    printf("\n\n\t\t\tEnter Book Name to search:");
    fflush(stdin);
    fgets(bookName,MAX_BOOK_NAME,stdin);
    while (fread (&addBookInfoInDataBase, sizeof(addBookInfoInDataBase), 1, fp))
    {
        if(!strcmp(addBookInfoInDataBase.bookName, bookName))
        {
            found = 1;
            break;
        }
    }
    if(found)
    {
        printf("\n\t\t\tBook id = %u\n",addBookInfoInDataBase.books_id);
        printf("\t\t\tBook name = %s",addBookInfoInDataBase.bookName);
        printf("\t\t\tBook authorName = %s",addBookInfoInDataBase.authorName);
        printf("\t\t\tBook issue date(day/month/year) =  (%d/%d/%d)",addBookInfoInDataBase.bookIssueDate.dd,
               addBookInfoInDataBase.bookIssueDate.mm, addBookInfoInDataBase.bookIssueDate.yyyy);
    }
    else
    {
        printf("\n\t\t\tNo Record");
    }
    fclose(fp);
    printf("\n\n\n\t\t\tPress any key to go to main menu.....");
    getchar();
}
// v books function
void viewBooks()
{
    int found = 0;
    char bookName[MAX_BOOK_NAME] = {0};
    s_BooksInfo addBookInfoInDataBase = {0};
    FILE *fp = NULL;
    int status = 0;
    unsigned int countBook = 1;
    headMessage("VIEW BOOKS DETAILS");
    fp = fopen(FILE_NAME,"rb");
    if(fp == NULL)
    {
        printf("File is not opened\n");
        exit(1);
    }
    if (fseek(fp,FILE_HEADER_SIZE,SEEK_SET) != 0)
    {
        fclose(fp);
        printf("Facing issue while reading file\n");
        exit(1);
    }
    while (fread (&addBookInfoInDataBase, sizeof(addBookInfoInDataBase), 1, fp))
    {
        printf("\n\t\t\tBook Count = %d\n\n",countBook);
        printf("\t\t\tBook id = %u",addBookInfoInDataBase.books_id);
        printf("\n\t\t\tBook name = %s",addBookInfoInDataBase.bookName);
        printf("\t\t\tBook authorName = %s",addBookInfoInDataBase.authorName);
        printf("\t\t\tBook issue date(day/month/year) =  (%d/%d/%d)\n\n",addBookInfoInDataBase.bookIssueDate.dd,
               addBookInfoInDataBase.bookIssueDate.mm, addBookInfoInDataBase.bookIssueDate.yyyy);
        found = 1;
        ++countBook;
    }
    fclose(fp);
    if(!found)
    {
        printf("\n\t\t\tNo Record");
    }
    printf("\n\n\t\t\tPress any key to go to main menu.....");
    fflush(stdin);
    getchar();
}
// delete function
void deleteBooks()
{
    int found = 0;
    int bookDelete = 0;
    sFileHeader fileHeaderInfo = {0};
    char bookName[MAX_BOOK_NAME] = {0};
    s_BooksInfo addBookInfoInDataBase = {0};
    FILE *fp = NULL;
    FILE *tmpFp = NULL;
    int status = 0;
    headMessage("Delete Books Details");
    fp = fopen(FILE_NAME,"rb");
    if(fp == NULL)
    {
        printf("File is not opened\n");
        exit(1);
    }
    tmpFp = fopen("tmp.bin","wb");
    if(tmpFp == NULL)
    {
        fclose(fp);
        printf("File is not opened\n");
        exit(1);
    }
    fread (&fileHeaderInfo,FILE_HEADER_SIZE, 1, fp);
    fwrite(&fileHeaderInfo,FILE_HEADER_SIZE, 1, tmpFp);
    printf("\n\t\t\tEnter Book ID NO. for delete:");
    scanf("%d",&bookDelete);
    while (fread (&addBookInfoInDataBase, sizeof(addBookInfoInDataBase), 1, fp))
    {
        if(addBookInfoInDataBase.books_id != bookDelete)
        {
            fwrite(&addBookInfoInDataBase,sizeof(addBookInfoInDataBase), 1, tmpFp);
        }
        else
        {
            found = 1;
        }
    }
    (found)? printf("\n\t\t\tRecord deleted successfully....."):printf("\n\t\t\tRecord not found");
    fclose(fp);
    fclose(tmpFp);
    remove(FILE_NAME);
    rename("tmp.bin",FILE_NAME);
}

void logout(){
	menu();
}
int main()
{
   

    menu();
   


}
